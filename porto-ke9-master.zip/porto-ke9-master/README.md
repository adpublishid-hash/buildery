# El Raka — Portofolio Single Page

Website portofolio satu halaman bergaya sinematik: minimalis, tipografi kondensat
besar, penuh animasi scroll dan parallax. Dibangun dengan Next.js 16 (App Router),
Tailwind CSS v4, [shadcn/ui](https://ui.shadcn.com/docs/installation/next),
[Motion](https://motion.dev) dan [Lenis](https://lenis.darkroom.engineering).

## Menjalankan

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # build produksi
npm run lint
```

## Mengubah konten

Semua teks, proyek, layanan, penghargaan, pengalaman, testimoni, dan link sosial
ada di satu berkas: **`lib/data.ts`**. Ubah di sana, seluruh halaman ikut berubah.

Gambar memakai placeholder Unsplash lewat helper `img()` di berkas yang sama.
Untuk memakai aset sendiri:

1. Taruh file di `public/` lalu pakai path `/nama-file.jpg`, atau
2. Pakai URL eksternal — tambahkan domainnya ke `images.remotePatterns` di
   [next.config.ts](next.config.ts).

## Struktur

```
app/
  layout.tsx          # font (Geist + Oswald), metadata, provider smooth scroll
  page.tsx            # urutan section halaman
  globals.css         # token shadcn + utilitas kustom (.section-light, .grain, .text-outline)
lib/data.ts           # SEED DATA — sumber seluruh konten
components/
  site/               # section halaman
    preloader.tsx     # layar pembuka + counter 000–100
    cursor.tsx        # kursor kustom (aktif di pointer halus saja)
    site-header.tsx   # header mix-blend + menu layar penuh (shadcn Sheet)
    hero.tsx          # hero carousel 3 proyek unggulan + parallax
    ticker.tsx        # marquee kecepatan-scroll
    about.tsx         # bio, statistik counter, proses kerja
    showreel.tsx      # panel showreel yang membesar saat scroll
    work.tsx          # daftar proyek + preview mengikuti kursor + detail (Dialog)
    services.tsx      # layanan (Accordion)
    recognition.tsx   # penghargaan, timeline karier, marquee klien
    testimonials.tsx  # testimoni bergilir
    cta.tsx           # ajakan kerja sama dengan parallax
    contact.tsx       # form + footer + nama besar outline
    mobile-cta.tsx    # bar CTA melayang khusus mobile
    section-meta.tsx  # baris meta kecil di atas judul section
  motion/             # primitif animasi (reveal, parallax, marquee, counter, magnetic)
  providers/          # SmoothScroll (Lenis)
  ui/                 # komponen shadcn/ui
hooks/
  use-media-query.ts  # useMediaQuery / useReducedMotion / useIsMobile
  use-scroll-locked.ts# deteksi dialog atau menu yang sedang terbuka
```

## Perlakuan khusus mobile

- **Hero**: gradien gelap vertikal agar teks terbaca di atas foto, chip meta
  (kategori / klien / tahun), dot indikator dengan area sentuh 44px, thumbnail
  "Next", dan **geser (swipe) horizontal** untuk berpindah proyek.
- **Header**: `mix-blend-difference` hanya dipakai dari breakpoint `md` ke atas;
  di mobile memakai scrim di puncak halaman lalu berubah jadi bar gelap
  ber-blur setelah scroll, dan menyingkir saat dialog/menu terbuka.
- **Work**: setiap baris punya thumbnail dan panah — pengganti preview
  yang mengikuti kursor (desktop saja).
- **About**: bio panjang diringkas jadi dua paragraf dengan tombol
  "Baca selengkapnya".
- **Kontak**: tombol cepat Email & WhatsApp, info dua kolom, input 16px agar
  iOS tidak auto-zoom, plus `autoComplete`/`inputMode` yang sesuai.
- **CTA melayang** muncul setelah hero terlewat dan menghilang di section
  kontak atau saat ada modal terbuka.
- Semua area sentuh minimal 44px dan padding bawah menghormati
  `env(safe-area-inset-bottom)`.

## Catatan

- **Form kontak masih demo.** `handleSubmit` di
  [components/site/contact.tsx](components/site/contact.tsx) hanya menampilkan
  state sukses — sambungkan ke Server Action, Resend, atau CRM pilihanmu.
- **Tombol play showreel** belum memutar video; hubungkan ke modal video atau
  embed Vimeo/YouTube sesuai kebutuhan.
- Seluruh animasi menghormati `prefers-reduced-motion`: smooth scroll, preloader,
  kursor kustom, dan efek grain otomatis nonaktif.
- Halaman memakai tema gelap sebagai dasar; section terang (About, Services,
  Testimonials) memakai utilitas `.section-light` yang menimpa token warna
  shadcn secara lokal.

## Menambah komponen shadcn

```bash
npx shadcn@latest add <nama-komponen>
```
