/**
 * Seed data — satu-satunya sumber konten untuk halaman portofolio.
 * Ganti nilai di sini untuk mengubah seluruh isi website.
 */

export type Project = {
  id: string;
  index: string;
  title: string;
  client: string;
  category: string;
  year: string;
  role: string;
  location: string;
  duration: string;
  description: string;
  about: string;
  image: string;
  cover: string;
  tags: string[];
  awards?: string[];
};

export type Service = {
  id: string;
  title: string;
  summary: string;
  detail: string;
  deliverables: string[];
};

export type Experience = {
  period: string;
  role: string;
  company: string;
  location: string;
  description: string;
};

export type Award = {
  year: string;
  title: string;
  organization: string;
  category: string;
};

export type Testimonial = {
  quote: string;
  name: string;
  title: string;
  company: string;
};

/**
 * Placeholder gambar (Unsplash, di-grade monokrom lewat parameter `sat=-100`).
 * Ganti `id` dengan aset asli — jika memakai domain lain, tambahkan domain itu
 * ke `images.remotePatterns` di next.config.ts.
 */
const img = (id: string, w = 1400, h = 1800) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&h=${h}&q=80&sat=-100`;

export const profile = {
  name: "Raka Aditama",
  brand: "EL RAKA",
  initials: "RA",
  role: "Film Director & Visual Storyteller",
  tagline: "Directing moments that matter",
  headline: ["Dark", "Rising", "2001"],
  status: "Available for Q4 2026 bookings",
  statusShort: "Open for Q4 2026",
  location: "Jakarta, Indonesia",
  timezone: "Asia/Jakarta",
  address: "Jl. Senopati Raya 118, Kebayoran Baru, Jakarta Selatan 12190",
  addressShort: "Kebayoran Baru, Jakarta 12190",
  email: "hello@elraka.studio",
  phone: "+62 812 8890 4417",
  portrait: img("photo-1485846234645-a62644f84728", 1600, 1100),
  since: 2013,
  shortBio:
    "Sutradara dan storyteller visual yang membangun film pendek berkarakter kuat — menghubungkan brand dengan audiens lewat narasi yang punya maksud.",
  bio: [
    "Raka Aditama adalah sutradara dan visual storyteller asal Jakarta yang bekerja di persimpangan antara film komersial dan dokumenter. Selama lebih dari satu dekade, karyanya berpusat pada satu pertanyaan sederhana: bagaimana sebuah gambar bisa membuat orang merasa sesuatu yang tidak bisa dijelaskan dengan kata-kata.",
    "Berangkat dari latar belakang fotografi jalanan di Kota Tua, Raka membangun bahasa visual yang bertumpu pada cahaya keras, tekstur nyata, dan gerak kamera yang sabar. Pendekatannya menolak kilau berlebihan — setiap frame dibangun dari riset lapangan, percakapan panjang dengan subjek, dan keyakinan bahwa detail kecil menyimpan cerita paling jujur.",
    "Sejak mendirikan El Raka Studio pada 2019, karyanya mencakup kampanye untuk brand global, film musik, dan dokumenter pendek yang tayang di festival Asia Tenggara — diputar di Busan Short Film Showcase, memenangkan Silver di AdFest, dan masuk daftar pendek Young Director Award.",
    "Di luar set, Raka mengajar kelas penyutradaraan untuk sineas muda di Jakarta dan Yogyakarta, serta menulis catatan mingguan tentang kerja kreatif yang dibaca lebih dari 12.000 orang.",
  ],
  manifesto:
    "Saya tidak membuat iklan. Saya membuat memori pendek yang kebetulan punya logo di akhirnya.",
  socials: [
    { label: "Instagram", handle: "@elraka.films", href: "https://instagram.com" },
    { label: "Vimeo", handle: "/elraka", href: "https://vimeo.com" },
    { label: "Behance", handle: "/rakaaditama", href: "https://behance.net" },
    { label: "LinkedIn", handle: "/in/rakaaditama", href: "https://linkedin.com" },
  ],
};

export const stats = [
  { value: 148, suffix: "+", label: "Projects delivered" },
  { value: 12, suffix: "yrs", label: "Years directing" },
  { value: 27, suffix: "", label: "Awards & nominations" },
  { value: 19, suffix: "", label: "Countries filmed in" },
];

export const marqueeWords = [
  "Direction",
  "Cinematography",
  "Brand Films",
  "Documentary",
  "Music Video",
  "Colour Grading",
  "Creative Strategy",
];

export const projects: Project[] = [
  {
    id: "dark-rising",
    index: "01",
    title: "Dark Rising 2001",
    client: "Aperture Media Ltd",
    category: "Short Film",
    year: "2025",
    role: "Director / Writer",
    location: "Jakarta, Indonesia",
    duration: "12 min",
    description:
      "Film ini menangkap energi mentah di balik kehidupan urban — cara gerak mendefinisikan sebuah kota, dan bagaimana ritme visual bisa bercerita.",
    about:
      "Berfokus pada pencahayaan kontras tinggi dan gerak terkendali, kami membangun tekstur gritty yang terasa membumi sekaligus sangat personal.",
    image: img("photo-1516035069371-29a1b244cc32", 1400, 1800),
    cover: img("photo-1478720568477-152d9b164e26", 2000, 1200),
    tags: ["16mm", "Night Shoot", "Anamorphic"],
    awards: ["Busan Short Film Showcase 2025"],
  },
  {
    id: "project-noir",
    index: "02",
    title: "Project Noir: Phase One",
    client: "Maison Kuro",
    category: "Fashion Campaign",
    year: "2025",
    role: "Director",
    location: "Seoul, South Korea",
    duration: "90 sec",
    description:
      "Kampanye mode monokrom yang bertumpu pada pencahayaan keras dan siluet struktural untuk peluncuran lini apparel mewah.",
    about:
      "Satu ruang, satu sumber cahaya, dan sembilan pergantian wardrobe. Semua transisi dilakukan in-camera tanpa satu pun cut tersembunyi.",
    image: img("photo-1492691527719-9d1e07e534b4", 1400, 1800),
    cover: img("photo-1517604931442-7e0c8ed2963c", 2000, 1200),
    tags: ["In-camera", "Studio", "Monochrome"],
    awards: ["AdFest Silver — Craft"],
  },
  {
    id: "salt-and-static",
    index: "03",
    title: "Salt & Static",
    client: "Nusantara Coffee Co.",
    category: "Brand Film",
    year: "2024",
    role: "Director / DOP",
    location: "Flores, Indonesia",
    duration: "4 min",
    description:
      "Perjalanan tiga minggu menyusuri pesisir timur untuk merekam petani kopi generasi ketiga dan laut yang membentuk mereka.",
    about:
      "Diambil sepenuhnya dengan cahaya alami dan kru enam orang. Tidak ada naskah — hanya percakapan yang direkam selama 21 hari.",
    image: img("photo-1500048993953-d23a436266cf", 1400, 1800),
    cover: img("photo-1503095396549-807759245b35", 2000, 1200),
    tags: ["Documentary", "Natural Light", "Handheld"],
  },
  {
    id: "midnight-frequency",
    index: "04",
    title: "Midnight Frequency",
    client: "Rara & The Void",
    category: "Music Video",
    year: "2024",
    role: "Director",
    location: "Bandung, Indonesia",
    duration: "3 min 40 sec",
    description:
      "Video musik satu-take yang mengikuti seorang penyanyi menyusuri tujuh ruangan, masing-masing dengan aturan cahaya sendiri.",
    about:
      "Empat malam rehearsal, sebelas percobaan, dan take kesembilan yang akhirnya dipakai. Semua praktikal, tanpa VFX.",
    image: img("photo-1470071459604-3b5ec3a7fe05", 1400, 1800),
    cover: img("photo-1524758631624-e2822e304c36", 2000, 1200),
    tags: ["One-take", "Practical FX", "Steadicam"],
    awards: ["Young Director Award — Shortlist"],
  },
  {
    id: "the-long-quiet",
    index: "05",
    title: "The Long Quiet",
    client: "Yayasan Rimba Timur",
    category: "Documentary",
    year: "2023",
    role: "Director / Editor",
    location: "Kalimantan, Indonesia",
    duration: "24 min",
    description:
      "Potret satu keluarga penjaga hutan yang tinggal delapan jam dari jalan aspal terdekat.",
    about:
      "Difilmkan selama dua musim, dengan izin adat penuh, dan disunting bersama komunitas sebelum tayang perdana.",
    image: img("photo-1499750310107-5fef28a66643", 1400, 1800),
    cover: img("photo-1506905925346-21bda4d32df4", 2000, 1200),
    tags: ["Long-form", "Field Recording", "Community"],
  },
  {
    id: "concrete-bloom",
    index: "06",
    title: "Concrete Bloom",
    client: "Astra Urban Living",
    category: "Architecture Film",
    year: "2023",
    role: "Director",
    location: "Singapore",
    duration: "2 min",
    description:
      "Studi gerak tentang bagaimana cahaya berpindah melintasi beton selama satu hari penuh di menara residensial.",
    about:
      "Timelapse motion-control 36 jam, dipadukan dengan potret penghuni yang direkam pada jam yang sama persis.",
    image: img("photo-1542038784456-1ea8e935640e", 1400, 1800),
    cover: img("photo-1533928298208-27ff66555d8d", 2000, 1200),
    tags: ["Motion Control", "Timelapse", "Architecture"],
  },
];

export const services: Service[] = [
  {
    id: "direction",
    title: "Film Direction",
    summary: "Dari treatment sampai final grade.",
    detail:
      "Saya masuk sejak brief pertama — menyusun treatment, memilih kru, mengarahkan talent, dan menjaga tone tetap konsisten sampai warna terakhir dikunci.",
    deliverables: [
      "Treatment & mood film",
      "Casting direction",
      "On-set directing",
      "Final cut supervision",
    ],
  },
  {
    id: "cinematography",
    title: "Cinematography",
    summary: "Cahaya keras, gerak sabar, warna yang jujur.",
    detail:
      "Untuk proyek berskala kecil sampai menengah, saya memegang kamera sendiri. Pendekatan saya bertumpu pada satu sumber cahaya utama dan komposisi yang membiarkan ruang bernapas.",
    deliverables: [
      "Lighting design",
      "Lens & format testing",
      "Camera operating",
      "LUT & look development",
    ],
  },
  {
    id: "brand-strategy",
    title: "Creative Strategy",
    summary: "Menemukan cerita sebelum menyalakan kamera.",
    detail:
      "Sebelum produksi, saya bekerja bersama tim brand untuk menemukan satu kebenaran yang layak difilmkan — lalu membangun seluruh kampanye di sekitarnya.",
    deliverables: [
      "Audience research",
      "Narrative platform",
      "Campaign architecture",
      "Content roadmap",
    ],
  },
  {
    id: "post",
    title: "Post Production",
    summary: "Edit, grade, sound, selesai.",
    detail:
      "Studio menangani penyuntingan, colour grading, sound design, dan mastering multi-format untuk broadcast, cinema, maupun sosial.",
    deliverables: [
      "Offline & online edit",
      "Colour grading",
      "Sound design & mix",
      "Multi-format delivery",
    ],
  },
];

export const experiences: Experience[] = [
  {
    period: "2019 — Now",
    role: "Founder & Director",
    company: "El Raka Studio",
    location: "Jakarta",
    description:
      "Memimpin studio berisi sembilan orang yang menggarap brand film, dokumenter, dan kampanye regional untuk klien di enam negara.",
  },
  {
    period: "2016 — 2019",
    role: "Senior Director",
    company: "Northlight Films",
    location: "Singapore",
    description:
      "Menyutradarai lebih dari 60 produksi komersial untuk klien FMCG, otomotif, dan teknologi di Asia Tenggara.",
  },
  {
    period: "2014 — 2016",
    role: "Director of Photography",
    company: "Kolektif Ruang Gelap",
    location: "Yogyakarta",
    description:
      "Menangani sinematografi untuk film pendek independen dan dokumenter kolaboratif berbasis komunitas.",
  },
  {
    period: "2013 — 2014",
    role: "Camera Assistant",
    company: "Freelance",
    location: "Jakarta",
    description:
      "Memulai dari set kecil, belajar cahaya dan lensa dari kru yang mengizinkan terlalu banyak pertanyaan.",
  },
];

export const awards: Award[] = [
  { year: "2025", title: "Busan Short Film Showcase", organization: "BIFF", category: "Official Selection" },
  { year: "2025", title: "AdFest Silver", organization: "AdFest Asia", category: "Film Craft — Direction" },
  { year: "2024", title: "Young Director Award", organization: "YDA Cannes", category: "Shortlist — Music Video" },
  { year: "2024", title: "Citra Pariwara Gold", organization: "Citra Pariwara", category: "Best Brand Film" },
  { year: "2023", title: "Jogja-NETPAC Asian Film Festival", organization: "JAFF", category: "Documentary Competition" },
  { year: "2022", title: "Kancil Awards Bronze", organization: "Kancil", category: "Cinematography" },
];

export const clients = [
  "Maison Kuro",
  "Nusantara Coffee",
  "Astra Urban",
  "Aperture Media",
  "Rimba Timur",
  "Northlight",
  "Studio Ombak",
  "Kirana Group",
];

export const testimonials: Testimonial[] = [
  {
    quote:
      "Raka tidak pernah datang dengan jawaban. Yang datang adalah pertanyaan yang membuat brief kami jadi jauh lebih baik.",
    name: "Anindya Prameswari",
    title: "Head of Brand",
    company: "Maison Kuro",
  },
  {
    quote:
      "Kami memberi tiga hari syuting dan anggaran yang ketat. Yang kembali terasa seperti film berdurasi penuh.",
    name: "Daniel Oh",
    title: "Marketing Director",
    company: "Astra Urban Living",
  },
  {
    quote:
      "Set-nya tenang, terorganisir, dan entah bagaimana selalu selesai lebih cepat. Itu langka.",
    name: "Sinta Halim",
    title: "Executive Producer",
    company: "Northlight Films",
  },
];

export const process = [
  { step: "01", title: "Listen", text: "Percakapan panjang sebelum satu pun gambar dibicarakan." },
  { step: "02", title: "Frame", text: "Treatment, referensi, dan aturan visual yang disepakati bersama." },
  { step: "03", title: "Shoot", text: "Set kecil, kru tepat, jadwal yang menghormati semua orang." },
  { step: "04", title: "Finish", text: "Grade, sound, dan delivery untuk setiap format yang dibutuhkan." },
];

export const navLinks = [
  { label: "Work", href: "#work", index: "01" },
  { label: "About", href: "#about", index: "02" },
  { label: "Services", href: "#services", index: "03" },
  { label: "Recognition", href: "#recognition", index: "04" },
  { label: "Contact", href: "#contact", index: "05" },
];
