"use client";

import * as React from "react";

/**
 * True ketika ada overlay Radix (dialog / sheet) yang mengunci scroll body.
 * Dipakai untuk menyingkirkan elemen melayang saat modal terbuka.
 */
export function useScrollLocked() {
  const [locked, setLocked] = React.useState(false);

  React.useEffect(() => {
    const body = document.body;
    const sync = () => setLocked(body.hasAttribute("data-scroll-locked"));
    const observer = new MutationObserver(sync);
    observer.observe(body, {
      attributes: true,
      attributeFilter: ["data-scroll-locked"],
    });
    return () => observer.disconnect();
  }, []);

  return locked;
}
