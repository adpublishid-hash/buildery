"use client";

import * as React from "react";

/**
 * Membaca media query tanpa setState di dalam effect.
 * Di server selalu mengembalikan `false`.
 */
export function useMediaQuery(query: string) {
  const subscribe = React.useCallback(
    (onChange: () => void) => {
      const list = window.matchMedia(query);
      list.addEventListener("change", onChange);
      return () => list.removeEventListener("change", onChange);
    },
    [query],
  );

  return React.useSyncExternalStore(
    subscribe,
    () => window.matchMedia(query).matches,
    () => false,
  );
}

export const useReducedMotion = () =>
  useMediaQuery("(prefers-reduced-motion: reduce)");

/** Breakpoint mobile mengikuti `md` milik Tailwind (768px). */
export const useIsMobile = () => useMediaQuery("(max-width: 767px)");
