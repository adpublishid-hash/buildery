"use client";

import * as React from "react";
import { motion, type Variants } from "motion/react";

import { cn } from "@/lib/utils";

const EASE = [0.16, 1, 0.3, 1] as const;

/** Fade + rise saat elemen masuk viewport. */
export function FadeIn({
  children,
  className,
  delay = 0,
  y = 24,
  once = true,
  as = "div",
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  y?: number;
  once?: boolean;
  as?: "div" | "section" | "span" | "li";
}) {
  const Comp = motion[as] as typeof motion.div;
  return (
    <Comp
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once, margin: "-12% 0px -12% 0px" }}
      transition={{ duration: 0.9, delay, ease: EASE }}
    >
      {children}
    </Comp>
  );
}

/** Teks besar yang muncul kata demi kata dari balik mask. */
export function TextReveal({
  text,
  className,
  wordClassName,
  delay = 0,
  stagger = 0.06,
  once = true,
}: {
  text: string;
  className?: string;
  wordClassName?: string;
  delay?: number;
  stagger?: number;
  once?: boolean;
}) {
  const words = text.split(" ");

  const container: Variants = {
    hidden: {},
    show: { transition: { delayChildren: delay, staggerChildren: stagger } },
  };

  const word: Variants = {
    hidden: { y: "115%", rotate: 3 },
    show: { y: "0%", rotate: 0, transition: { duration: 1, ease: EASE } },
  };

  return (
    <motion.span
      className={cn("inline-block", className)}
      variants={container}
      initial="hidden"
      whileInView="show"
      viewport={{ once, margin: "-10% 0px" }}
      aria-label={text}
    >
      {words.map((w, i) => (
        <span
          key={`${w}-${i}`}
          className="inline-block overflow-hidden py-[0.06em] align-bottom"
          aria-hidden
        >
          <motion.span className={cn("inline-block", wordClassName)} variants={word}>
            {w}
            {i < words.length - 1 ? " " : ""}
          </motion.span>
        </span>
      ))}
    </motion.span>
  );
}

/** Blok konten yang tersingkap dari balik tirai gelap. */
export function CurtainReveal({
  children,
  className,
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <motion.div
      className={cn("relative overflow-hidden", className)}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-10% 0px" }}
    >
      <motion.div
        variants={{
          hidden: { y: "40%", opacity: 0 },
          show: {
            y: "0%",
            opacity: 1,
            transition: { duration: 1.1, delay: delay + 0.1, ease: EASE },
          },
        }}
      >
        {children}
      </motion.div>
      <motion.span
        className="pointer-events-none absolute inset-0 z-10 bg-background"
        variants={{
          hidden: { scaleY: 1 },
          show: {
            scaleY: 0,
            transition: { duration: 1.1, delay, ease: EASE },
          },
        }}
        style={{ originY: 0 }}
      />
    </motion.div>
  );
}

/** Garis horizontal tipis yang menggambar dirinya sendiri. */
export function LineDraw({ className, delay = 0 }: { className?: string; delay?: number }) {
  return (
    <motion.div
      className={cn("h-px w-full origin-left bg-border", className)}
      initial={{ scaleX: 0 }}
      whileInView={{ scaleX: 1 }}
      viewport={{ once: true, margin: "-5% 0px" }}
      transition={{ duration: 1.2, delay, ease: EASE }}
    />
  );
}
