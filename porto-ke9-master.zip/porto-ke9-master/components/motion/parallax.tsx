"use client";

import * as React from "react";
import Image from "next/image";
import { motion, useScroll, useSpring, useTransform } from "motion/react";

import { cn } from "@/lib/utils";

/**
 * Menggeser konten pada sumbu Y mengikuti posisi scroll.
 * `speed` positif = bergerak lebih lambat dari halaman (mundur ke belakang).
 */
export function Parallax({
  children,
  className,
  speed = 0.15,
  stiffness = 120,
}: {
  children: React.ReactNode;
  className?: string;
  speed?: number;
  stiffness?: number;
}) {
  const ref = React.useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const raw = useTransform(
    scrollYProgress,
    [0, 1],
    [`${speed * 100}%`, `${speed * -100}%`],
  );
  const y = useSpring(raw, { stiffness, damping: 30, mass: 0.4 });

  return (
    <div ref={ref} className={className}>
      <motion.div style={{ y }} className="h-full w-full will-change-transform">
        {children}
      </motion.div>
    </div>
  );
}

/**
 * Gambar dengan parallax internal: frame diam, isi gambar bergerak.
 * Skala sedikit di-overshoot supaya tidak ada celah kosong saat bergeser.
 */
export function ParallaxImage({
  src,
  alt,
  className,
  imageClassName,
  amount = 18,
  scale = 1.25,
  priority = false,
  sizes = "(max-width: 768px) 100vw, 50vw",
  overlay = true,
  children,
}: {
  src: string;
  alt: string;
  className?: string;
  imageClassName?: string;
  amount?: number;
  scale?: number;
  priority?: boolean;
  sizes?: string;
  overlay?: boolean;
  children?: React.ReactNode;
}) {
  const ref = React.useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const raw = useTransform(scrollYProgress, [0, 1], [`-${amount}%`, `${amount}%`]);
  const y = useSpring(raw, { stiffness: 140, damping: 30, mass: 0.4 });

  return (
    <div
      ref={ref}
      className={cn("relative overflow-hidden bg-neutral-900", className)}
    >
      <motion.div
        style={{ y, scale }}
        className="absolute inset-0 will-change-transform"
      >
        <Image
          src={src}
          alt={alt}
          fill
          priority={priority}
          sizes={sizes}
          className={cn("object-cover", imageClassName)}
        />
      </motion.div>
      {overlay ? (
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-black/30" />
      ) : null}
      {children}
    </div>
  );
}

/** Membesar / mengecil mengikuti scroll — dipakai untuk panel showreel. */
export function ScrollScale({
  children,
  className,
  from = 0.82,
  to = 1,
  radius = 32,
}: {
  children: React.ReactNode;
  className?: string;
  from?: number;
  to?: number;
  radius?: number;
}) {
  const ref = React.useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "center center"],
  });

  const scale = useSpring(useTransform(scrollYProgress, [0, 1], [from, to]), {
    stiffness: 120,
    damping: 28,
  });
  const borderRadius = useTransform(scrollYProgress, [0, 1], [radius, 0]);

  return (
    <div ref={ref} className={className}>
      <motion.div
        style={{ scale, borderRadius }}
        className="overflow-hidden will-change-transform"
      >
        {children}
      </motion.div>
    </div>
  );
}
