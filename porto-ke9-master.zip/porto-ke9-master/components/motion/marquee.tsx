"use client";

import * as React from "react";
import {
  motion,
  useAnimationFrame,
  useMotionValue,
  useScroll,
  useSpring,
  useTransform,
  useVelocity,
} from "motion/react";

import { cn } from "@/lib/utils";

/**
 * Marquee tak berujung yang ikut mempercepat/melambat sesuai kecepatan scroll.
 */
export function Marquee({
  children,
  baseVelocity = 40,
  className,
  itemClassName,
  repeat = 4,
  reverse = false,
}: {
  children: React.ReactNode;
  baseVelocity?: number;
  className?: string;
  itemClassName?: string;
  repeat?: number;
  reverse?: boolean;
}) {
  const baseX = useMotionValue(0);
  const { scrollY } = useScroll();
  const scrollVelocity = useVelocity(scrollY);
  const smooth = useSpring(scrollVelocity, { damping: 50, stiffness: 400 });
  const factor = useTransform(smooth, [-1500, 0, 1500], [-4, 1, 4], {
    clamp: false,
  });

  const x = useTransform(baseX, (v) => `${wrap(-100 / repeat, 0, v)}%`);
  const direction = React.useRef(reverse ? -1 : 1);

  useAnimationFrame((_, delta) => {
    let moveBy = direction.current * baseVelocity * (delta / 1000);
    const f = factor.get();
    if (f < 0) direction.current = reverse ? 1 : -1;
    else direction.current = reverse ? -1 : 1;
    moveBy += moveBy * Math.abs(f);
    baseX.set(baseX.get() + moveBy / 10);
  });

  return (
    <div className={cn("relative flex overflow-hidden", className)}>
      <motion.div className="flex whitespace-nowrap will-change-transform" style={{ x }}>
        {Array.from({ length: repeat }).map((_, i) => (
          <span key={i} className={cn("flex shrink-0 items-center", itemClassName)} aria-hidden={i > 0}>
            {children}
          </span>
        ))}
      </motion.div>
    </div>
  );
}

function wrap(min: number, max: number, value: number) {
  const range = max - min;
  return ((((value - min) % range) + range) % range) + min;
}
