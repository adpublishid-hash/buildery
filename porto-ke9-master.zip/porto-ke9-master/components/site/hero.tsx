"use client";

import * as React from "react";
import Image from "next/image";
import { AnimatePresence, motion, useScroll, useTransform, type PanInfo } from "motion/react";
import { ArrowRight, ArrowDown } from "lucide-react";

import { Magnetic } from "@/components/motion/magnetic";
import { useIsMobile } from "@/hooks/use-media-query";
import { projects, profile } from "@/lib/data";
import { cn } from "@/lib/utils";

const EASE = [0.16, 1, 0.3, 1] as const;
const featured = projects.slice(0, 3);
const AUTOPLAY = 7000;
const SWIPE_THRESHOLD = 60;

export function Hero() {
  const [index, setIndex] = React.useState(0);
  const ref = React.useRef<HTMLElement>(null);
  const isMobile = useIsMobile();
  const project = featured[index];

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const imageY = useTransform(scrollYProgress, [0, 1], ["0%", "22%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", isMobile ? "24%" : "42%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  React.useEffect(() => {
    const id = window.setInterval(
      () => setIndex((i) => (i + 1) % featured.length),
      AUTOPLAY,
    );
    return () => window.clearInterval(id);
  }, []);

  const go = (direction: number) =>
    setIndex((i) => (i + direction + featured.length) % featured.length);

  const handleDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.x < -SWIPE_THRESHOLD) go(1);
    else if (info.offset.x > SWIPE_THRESHOLD) go(-1);
  };

  return (
    <section
      id="top"
      ref={ref}
      className="relative h-dvh min-h-[620px] w-full overflow-hidden bg-black text-white"
    >
      {/* Lapisan gambar dengan parallax */}
      <motion.div style={{ y: imageY }} className="absolute inset-0">
        <div className="absolute inset-0 md:left-[38%] xl:left-[34%] xl:right-[22%]">
          <AnimatePresence mode="sync">
            <motion.div
              key={project.id}
              initial={{ opacity: 0, scale: 1.12 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.4, ease: EASE }}
              className="absolute inset-0"
            >
              <Image
                src={project.image}
                alt={project.title}
                fill
                priority
                sizes="100vw"
                className="object-cover brightness-[1.18] contrast-[1.05]"
              />
            </motion.div>
          </AnimatePresence>

          {/* Mobile: gelap di bawah supaya teks tetap terbaca di atas foto */}
          <div className="absolute inset-0 bg-gradient-to-t from-black from-15% via-black/85 via-55% to-black/35 md:hidden" />
          {/* Desktop: gelap di kiri, foto terbuka di kanan */}
          <div className="absolute inset-0 hidden md:block md:bg-black/10" />
          <div className="absolute inset-0 hidden bg-gradient-to-r md:block md:from-black md:via-black/10 md:to-black/35" />
        </div>
      </motion.div>

      <GridLines />

      {/* Konten */}
      <motion.div
        style={{ y: textY, opacity }}
        drag={isMobile ? "x" : false}
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.12}
        dragMomentum={false}
        onDragEnd={handleDragEnd}
        className="relative z-10 flex h-full touch-pan-y flex-col justify-end px-5 pb-8 pt-24 md:px-10 md:pb-14 md:pt-28"
      >
        <div className="grid flex-1 grid-cols-1 content-end gap-8 xl:grid-cols-[minmax(0,1fr)_260px] xl:items-end">
          <div className="max-w-[46rem]">
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: EASE }}
              className="mb-4 font-mono text-[10px] uppercase tracking-[0.28em] text-white/50 md:mb-6 md:tracking-[0.32em]"
            >
              {"// Featured"} — {project.index} / 0{featured.length}
            </motion.p>

            {/* Judul ditukar lewat `key` — elemen lama langsung dilepas supaya
                tidak ada jeda kosong di antara dua proyek. */}
            <h1
              key={project.id}
              className="font-heading text-[15vw] uppercase leading-[0.85] sm:text-[12vw] xl:text-[8.5vw]"
            >
              {project.title.split(" ").map((word, i) => (
                <span
                  key={`${word}-${i}`}
                  className="inline-block overflow-hidden py-[0.02em]"
                >
                  <motion.span
                    className="inline-block"
                    initial={{ y: "110%" }}
                    animate={{ y: "0%" }}
                    transition={{ duration: 0.9, delay: i * 0.07, ease: EASE }}
                  >
                    {word}&nbsp;
                  </motion.span>
                </span>
              ))}
            </h1>

            {/* Meta ringkas — pengganti kolom credit sheet di layar kecil */}
            <div
              key={`${project.id}-chips`}
              className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-2 font-mono text-[10px] uppercase tracking-[0.2em] text-white/55 xl:hidden"
            >
              <span className="rounded-full border border-white/20 px-3 py-1">
                {project.category}
              </span>
              <span className="rounded-full border border-white/20 px-3 py-1">
                {project.client}
              </span>
              <span className="rounded-full border border-white/20 px-3 py-1">
                {project.year} — {project.duration}
              </span>
            </div>

            <motion.p
              key={`${project.id}-desc`}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.15, ease: EASE }}
              className="mt-4 line-clamp-3 max-w-md text-sm leading-relaxed text-white/65 md:mt-6 md:line-clamp-none md:text-base"
            >
              {project.description}
            </motion.p>

            <Magnetic className="mt-6 md:mt-8">
              <a
                href="#work"
                data-cursor="hover"
                className="group inline-flex min-h-11 items-center gap-3 rounded-full border border-white/40 px-6 py-3 text-sm transition-colors hover:bg-white hover:text-black md:px-7"
              >
                Read more
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
              </a>
            </Magnetic>
          </div>

          {/* Kolom meta ala credit sheet */}
          <motion.dl
            key={`${project.id}-meta`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="hidden space-y-6 border-l border-white/15 pl-6 font-mono text-[10px] uppercase tracking-[0.22em] xl:block"
          >
            <div>
              <dt className="text-white/40">Client</dt>
              <dd className="mt-2 text-white/85">{project.client}</dd>
            </div>
            <div>
              <dt className="text-white/40">About</dt>
              <dd className="mt-2 normal-case leading-relaxed tracking-normal text-white/60">
                {project.about}
              </dd>
            </div>
            <div>
              <dt className="text-white/40">Year / Runtime</dt>
              <dd className="mt-2 text-white/85">
                {project.year} — {project.duration}
              </dd>
            </div>
          </motion.dl>
        </div>

        {/* Kontrol bawah */}
        <div className="mt-6 flex items-end justify-between gap-4 md:mt-10 md:gap-6">
          <div className="flex items-center gap-4 md:gap-5">
            <button
              type="button"
              onClick={() => go(1)}
              aria-label={`Proyek berikutnya: ${featured[(index + 1) % featured.length].title}`}
              data-cursor="next"
              className="group relative size-14 shrink-0 overflow-hidden border border-white/20 md:size-20"
            >
              <Image
                src={featured[(index + 1) % featured.length].image}
                alt=""
                fill
                sizes="80px"
                className="object-cover opacity-60 transition-opacity group-hover:opacity-100"
              />
              <span className="absolute inset-x-0 bottom-0 bg-black/60 py-0.5 text-center font-mono text-[8px] uppercase tracking-[0.2em] text-white/80">
                Next
              </span>
            </button>

            <div className="flex items-center">
              {featured.map((p, i) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setIndex(i)}
                  aria-label={`Lihat ${p.title}`}
                  aria-current={i === index}
                  className="flex h-11 items-center px-1.5"
                >
                  <span
                    className={cn(
                      "block h-1.5 rounded-full transition-all duration-500",
                      i === index ? "w-8 bg-white" : "w-1.5 bg-white/40",
                    )}
                  />
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-6">
            <span className="hidden font-mono text-[10px] uppercase tracking-[0.28em] text-white/40 sm:block">
              {profile.status}
            </span>
            <motion.a
              href="#work"
              aria-label="Scroll ke bawah"
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
              className="flex size-11 items-center justify-center rounded-full border border-white/25 text-white/70"
            >
              <ArrowDown className="size-4" />
            </motion.a>
          </div>
        </div>

        <p className="mt-3 text-center font-mono text-[9px] uppercase tracking-[0.24em] text-white/25 md:hidden">
          Geser untuk proyek lain
        </p>
      </motion.div>
    </section>
  );
}

/** Garis vertikal tipis sebagai grid sinematik. */
export function GridLines({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "pointer-events-none absolute inset-0 z-[1] grid grid-cols-4 md:grid-cols-6",
        className,
      )}
      aria-hidden
    >
      {Array.from({ length: 6 }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ scaleY: 0 }}
          animate={{ scaleY: 1 }}
          transition={{ duration: 1.4, delay: 0.1 * i, ease: EASE }}
          className={cn(
            "h-full origin-top border-l border-white/[0.07]",
            i > 3 && "hidden md:block",
          )}
        />
      ))}
    </div>
  );
}
