"use client";

import * as React from "react";
import { motion } from "motion/react";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { FadeIn, LineDraw, TextReveal } from "@/components/motion/reveal";
import { SectionMeta } from "@/components/site/section-meta";
import { Parallax } from "@/components/motion/parallax";
import { services } from "@/lib/data";

export function Services() {
  return (
    <section
      id="services"
      className="section-light relative bg-background py-20 text-foreground md:py-32"
    >
      <div className="px-5 md:px-10">
        <SectionMeta
          label="// Capabilities"
          detail={`${services.length} services`}
          className="text-muted-foreground"
        />
        <LineDraw className="mt-4 md:mt-5" />

        <div className="mt-8 grid gap-5 md:mt-10 md:grid-cols-[1.2fr_1fr] md:gap-16">
          <h2 className="font-heading text-[12vw] uppercase leading-[0.86] md:text-[6.5vw]">
            <TextReveal text="What I do" />
          </h2>
          <FadeIn delay={0.15} className="self-end">
            <p className="max-w-md text-sm leading-relaxed text-muted-foreground md:text-base">
              Empat cara untuk bekerja bersama — dari mengarahkan satu film penuh
              sampai masuk sebagai partner kreatif untuk seluruh kampanye.
            </p>
          </FadeIn>
        </div>

        <Parallax speed={0.05} className="mt-10 md:mt-20">
          <Accordion type="single" collapsible defaultValue={services[0].id}>
            {services.map((service, i) => (
              <AccordionItem
                key={service.id}
                value={service.id}
                className="border-b border-border"
              >
                <AccordionTrigger
                  data-cursor="hover"
                  className="group/item min-h-14 items-center py-5 text-left hover:no-underline md:py-7"
                >
                  <div className="flex flex-1 flex-col gap-2 md:flex-row md:items-baseline md:gap-8">
                    <span className="font-mono text-[10px] text-muted-foreground">
                      0{i + 1}
                    </span>
                    <span className="font-heading text-3xl uppercase leading-none transition-transform duration-500 group-hover/item:translate-x-2 md:text-5xl">
                      {service.title}
                    </span>
                    <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground md:ml-auto md:pr-6">
                      {service.summary}
                    </span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pb-8 md:pb-10">
                  <div className="grid gap-6 md:grid-cols-[1fr_1fr] md:gap-8 md:pl-16">
                    <p className="max-w-lg text-sm leading-relaxed text-muted-foreground md:text-base">
                      {service.detail}
                    </p>
                    <ul className="grid gap-3 self-start">
                      {service.deliverables.map((item, j) => (
                        <motion.li
                          key={item}
                          initial={{ opacity: 0, x: -8 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.06 * j, duration: 0.5 }}
                          className="flex items-center gap-3 border-b border-border pb-3 font-mono text-[11px] uppercase tracking-[0.16em]"
                        >
                          <span className="size-1 rounded-full bg-foreground" />
                          {item}
                        </motion.li>
                      ))}
                    </ul>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Parallax>
      </div>
    </section>
  );
}
