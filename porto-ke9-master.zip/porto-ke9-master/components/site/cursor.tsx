"use client";

import * as React from "react";
import { motion, useMotionValue, useSpring } from "motion/react";

import { useMediaQuery, useReducedMotion } from "@/hooks/use-media-query";

/**
 * Kursor kustom: titik kecil mengikuti pointer, cincin melebar saat
 * berada di atas elemen ber-atribut `data-cursor`.
 */
export function Cursor() {
  const finePointer = useMediaQuery("(pointer: fine)");
  const reduced = useReducedMotion();
  const enabled = finePointer && !reduced;

  const [label, setLabel] = React.useState<string | null>(null);
  const [active, setActive] = React.useState(false);

  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const ringX = useSpring(x, { stiffness: 260, damping: 26, mass: 0.5 });
  const ringY = useSpring(y, { stiffness: 260, damping: 26, mass: 0.5 });

  React.useEffect(() => {
    if (!enabled) return;

    function onMove(event: MouseEvent) {
      x.set(event.clientX);
      y.set(event.clientY);
      const target = (event.target as HTMLElement | null)?.closest<HTMLElement>(
        "[data-cursor]",
      );
      setActive(Boolean(target));
      setLabel(target?.dataset.cursor || null);
    }

    window.addEventListener("mousemove", onMove, { passive: true });
    return () => window.removeEventListener("mousemove", onMove);
  }, [enabled, x, y]);

  if (!enabled) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[90] hidden md:block">
      <motion.div
        style={{ x, y }}
        className="absolute -ml-[3px] -mt-[3px] size-1.5 rounded-full bg-foreground mix-blend-difference"
      />
      <motion.div style={{ x: ringX, y: ringY }} className="absolute left-0 top-0">
        <div className="-translate-x-1/2 -translate-y-1/2">
          <motion.div
            animate={{
              width: active ? 88 : 34,
              height: active ? 88 : 34,
              opacity: active ? 1 : 0.45,
            }}
            transition={{ type: "spring", stiffness: 260, damping: 24 }}
            className="flex items-center justify-center rounded-full border border-foreground/60 bg-foreground/5 backdrop-blur-[1px]"
          >
            {label && label !== "hover" ? (
              <span className="text-center font-mono text-[9px] uppercase leading-tight tracking-[0.2em]">
                {label}
              </span>
            ) : null}
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
