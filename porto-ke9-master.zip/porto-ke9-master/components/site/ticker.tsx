"use client";

import { Marquee } from "@/components/motion/marquee";
import { marqueeWords } from "@/lib/data";

export function Ticker() {
  return (
    <div className="relative border-y border-white/10 bg-black py-5 text-white md:py-7">
      <Marquee baseVelocity={26} repeat={4} itemClassName="gap-8 pr-8 md:gap-14 md:pr-14">
        {marqueeWords.map((word) => (
          <span key={word} className="flex items-center gap-8 md:gap-14">
            <span className="font-heading text-2xl uppercase tracking-tight md:text-4xl">
              {word}
            </span>
            <span className="text-white/30">✳</span>
          </span>
        ))}
      </Marquee>
    </div>
  );
}
