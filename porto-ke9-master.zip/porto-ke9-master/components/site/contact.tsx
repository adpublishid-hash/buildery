"use client";

import * as React from "react";
import { AnimatePresence, motion } from "motion/react";
import { ArrowUp, Check, Mail, MessageCircle, Send } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FadeIn, LineDraw, TextReveal } from "@/components/motion/reveal";
import { SectionMeta } from "@/components/site/section-meta";
import { Marquee } from "@/components/motion/marquee";
import { Magnetic } from "@/components/motion/magnetic";
import { profile, services } from "@/lib/data";

const EASE = [0.16, 1, 0.3, 1] as const;

export function Contact() {
  const [sent, setSent] = React.useState(false);
  const [pending, setPending] = React.useState(false);

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    // Demo: belum terhubung ke backend / layanan email.
    setPending(true);
    window.setTimeout(() => {
      setPending(false);
      setSent(true);
    }, 900);
  }

  return (
    <footer id="contact" className="relative overflow-hidden bg-black text-white">
      <div className="px-5 pt-20 md:px-10 md:pt-32">
        <SectionMeta
          label="// Contact"
          detail={profile.status}
          className="text-white/40"
        />
        <LineDraw className="mt-4 bg-white/15 md:mt-5" />

        <div className="mt-8 grid gap-10 md:mt-12 md:grid-cols-[1fr_1fr] md:gap-20">
          <div>
            <h2 className="font-heading text-[12vw] uppercase leading-[0.86] md:text-[6vw]">
              <TextReveal text="Let us talk" />
            </h2>

            <FadeIn delay={0.15}>
              <p className="mt-5 max-w-md text-sm leading-relaxed text-white/60 md:mt-6">
                Ceritakan sedikit tentang proyeknya — timeline, skala, dan hal yang
                ingin dirasakan penonton. Biasanya saya balas dalam 1—2 hari kerja.
              </p>
            </FadeIn>

            {/* Aksi cepat — paling berguna di layar sentuh */}
            <div className="mt-6 flex flex-wrap gap-3 md:hidden">
              <a
                href={`mailto:${profile.email}`}
                className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full bg-white px-5 text-sm font-medium text-black"
              >
                <Mail className="size-4" />
                Email
              </a>
              <a
                href={`https://wa.me/${profile.phone.replace(/[^0-9]/g, "")}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-full border border-white/30 px-5 text-sm"
              >
                <MessageCircle className="size-4" />
                WhatsApp
              </a>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-6 md:mt-12 md:gap-8">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-white/35">
                  Email
                </p>
                <a
                  href={`mailto:${profile.email}`}
                  data-cursor="hover"
                  className="mt-1 inline-flex min-h-11 items-center break-all text-base transition-colors hover:text-white/70 md:text-lg"
                >
                  {profile.email}
                </a>
              </div>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-white/35">
                  Phone
                </p>
                <a
                  href={`tel:${profile.phone.replace(/\s/g, "")}`}
                  className="mt-1 inline-flex min-h-11 items-center text-base transition-colors hover:text-white/70 md:text-lg"
                >
                  {profile.phone}
                </a>
              </div>
              <div className="col-span-2 md:col-span-1">
                <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-white/35">
                  Studio
                </p>
                <p className="mt-2 text-sm leading-relaxed text-white/70">
                  {profile.address}
                </p>
              </div>
              <div className="col-span-2 md:col-span-1">
                <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-white/35">
                  Social
                </p>
                <ul className="mt-1">
                  {profile.socials.map((s) => (
                    <li key={s.label}>
                      <a
                        href={s.href}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex min-h-10 items-center text-sm text-white/70 transition-colors hover:text-white"
                      >
                        {s.label} <span className="text-white/35">{s.handle}</span>
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Formulir */}
          <FadeIn delay={0.1}>
            <div className="relative rounded-2xl border border-white/12 bg-white/[0.03] p-5 backdrop-blur-sm sm:p-6 md:p-10">
              <AnimatePresence mode="wait">
                {sent ? (
                  <motion.div
                    key="sent"
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.6, ease: EASE }}
                    className="flex min-h-[26rem] flex-col items-start justify-center"
                  >
                    <span className="flex size-12 items-center justify-center rounded-full border border-white/25">
                      <Check className="size-5" />
                    </span>
                    <p className="mt-6 font-heading text-4xl uppercase leading-none">
                      Pesan terkirim
                    </p>
                    <p className="mt-4 max-w-sm text-sm leading-relaxed text-white/55">
                      Terima kasih sudah menghubungi. Ini masih demo — hubungkan form
                      ini ke email atau CRM pilihanmu di{" "}
                      <code className="text-white/80">components/site/contact.tsx</code>.
                    </p>
                    <Button
                      variant="outline"
                      className="mt-8 border-white/25 bg-transparent text-white hover:bg-white hover:text-black"
                      onClick={() => setSent(false)}
                    >
                      Kirim pesan lain
                    </Button>
                  </motion.div>
                ) : (
                  <motion.form
                    key="form"
                    onSubmit={handleSubmit}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="grid gap-5"
                  >
                    <div className="grid gap-2">
                      <Label htmlFor="name" className="font-mono text-[10px] uppercase tracking-[0.24em] text-white/45">
                        Nama
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        required
                        autoComplete="name"
                        enterKeyHint="next"
                        placeholder="Nama lengkap"
                        className="h-11 rounded-lg border-white/15 bg-transparent text-white placeholder:text-white/25"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="email" className="font-mono text-[10px] uppercase tracking-[0.24em] text-white/45">
                        Email
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        autoComplete="email"
                        inputMode="email"
                        enterKeyHint="next"
                        placeholder="nama@perusahaan.com"
                        className="h-11 rounded-lg border-white/15 bg-transparent text-white placeholder:text-white/25"
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="service" className="font-mono text-[10px] uppercase tracking-[0.24em] text-white/45">
                        Kebutuhan
                      </Label>
                      <select
                        id="service"
                        name="service"
                        className="h-11 rounded-lg border border-white/15 bg-transparent px-3 text-sm text-white outline-none focus-visible:border-white/50"
                      >
                        {services.map((s) => (
                          <option key={s.id} value={s.id} className="bg-neutral-900">
                            {s.title}
                          </option>
                        ))}
                        <option value="other" className="bg-neutral-900">
                          Lainnya
                        </option>
                      </select>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="message" className="font-mono text-[10px] uppercase tracking-[0.24em] text-white/45">
                        Tentang proyek
                      </Label>
                      <Textarea
                        id="message"
                        name="message"
                        required
                        rows={5}
                        placeholder="Timeline, skala produksi, dan referensi visual..."
                        className="rounded-lg border-white/15 bg-transparent text-white placeholder:text-white/25"
                      />
                    </div>

                    <Magnetic strength={0.2}>
                      <Button
                        type="submit"
                        size="lg"
                        disabled={pending}
                        data-cursor="hover"
                        className="h-12 w-full rounded-full bg-white px-8 text-black hover:bg-white/85"
                      >
                        {pending ? "Mengirim…" : "Kirim pesan"}
                        <Send className="size-4" />
                      </Button>
                    </Magnetic>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
          </FadeIn>
        </div>
      </div>

      {/* Nama besar + baris penutup */}
      <div className="mt-16 select-none border-t border-white/10 py-7 md:mt-24 md:py-10">
        <Marquee baseVelocity={14} repeat={3} itemClassName="pr-10">
          <span className="font-heading text-[18vw] uppercase leading-[0.8] text-outline md:text-[13vw]">
            {profile.name} — {profile.role} —&nbsp;
          </span>
        </Marquee>
      </div>

      <div className="flex flex-col gap-3 border-t border-white/10 px-5 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-6 font-mono text-[10px] uppercase leading-relaxed tracking-[0.24em] text-white/35 md:flex-row md:items-center md:justify-between md:px-10 md:pb-6">
        <span>
          © {new Date().getFullYear()} {profile.brand} Studio. All rights reserved.
        </span>
        <span className="hidden md:inline">Built with Next.js, shadcn/ui & Motion</span>
        <a
          href="#top"
          data-cursor="hover"
          className="inline-flex min-h-11 items-center gap-2 transition-colors hover:text-white"
        >
          Back to top <ArrowUp className="size-3" />
        </a>
      </div>
    </footer>
  );
}
