import * as React from "react";

import { cn } from "@/lib/utils";

/**
 * Baris meta kecil di atas judul section.
 * Di mobile ditumpuk supaya tidak saling menabrak; di layar lebar sejajar.
 */
export function SectionMeta({
  label,
  detail,
  className,
}: {
  label: string;
  detail?: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-1 font-mono text-[10px] uppercase tracking-[0.28em] sm:flex-row sm:items-baseline sm:justify-between sm:gap-6",
        className,
      )}
    >
      <span>{label}</span>
      {detail ? <span className="opacity-60">{detail}</span> : null}
    </div>
  );
}
