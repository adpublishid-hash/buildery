"use client";

import * as React from "react";
import Image from "next/image";
import { motion, useScroll, useSpring, useTransform } from "motion/react";
import { Play } from "lucide-react";

import { ScrollScale } from "@/components/motion/parallax";
import { useIsMobile } from "@/hooks/use-media-query";
import { projects } from "@/lib/data";

const reel = projects[1];

export function Showreel() {
  const ref = React.useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const y = useSpring(useTransform(scrollYProgress, [0, 1], ["-14%", "14%"]), {
    stiffness: 140,
    damping: 30,
  });
  const isMobile = useIsMobile();
  const textY = useTransform(
    scrollYProgress,
    [0, 1],
    isMobile ? ["18%", "-18%"] : ["40%", "-40%"],
  );

  return (
    <section id="showreel" ref={ref} className="relative bg-black py-16 md:py-24">
      <ScrollScale className="px-0" from={0.86} to={1} radius={28}>
        <div className="relative h-[70vh] w-full overflow-hidden md:h-[92vh]">
          <motion.div style={{ y, scale: 1.22 }} className="absolute inset-0">
            <Image
              src={reel.cover}
              alt={reel.title}
              fill
              sizes="100vw"
              className="object-cover"
            />
          </motion.div>

          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-black/45" />
          <div className="grain absolute inset-0 overflow-hidden" aria-hidden />

          {/* Tombol play — di mobile diangkat agar tidak menabrak judul */}
          <div className="absolute inset-0 flex items-start justify-center pt-[24%] md:items-center md:pt-0">
            <motion.button
              type="button"
              data-cursor="play reel"
              aria-label="Putar showreel"
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.96 }}
              className="group relative flex size-20 items-center justify-center rounded-full border border-white/50 bg-white/10 backdrop-blur-sm md:size-28"
            >
              <span className="absolute inset-0 animate-ping rounded-full border border-white/20" />
              <Play className="size-6 translate-x-0.5 fill-white text-white md:size-8" />
            </motion.button>
          </div>

          {/* Info bawah */}
          <motion.div
            style={{ y: textY }}
            className="absolute inset-x-0 bottom-0 px-5 pb-8 text-white md:px-12 md:pb-14"
          >
            <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-white/50">
              {"// Showreel " + reel.year}
            </p>
            <h3 className="mt-3 max-w-3xl font-heading text-[10vw] uppercase leading-[0.9] md:mt-4 md:text-[5.5vw] md:leading-[0.86]">
              {reel.title}
            </h3>
            <p className="mt-4 max-w-lg text-sm leading-relaxed text-white/60">
              {reel.description}
            </p>
            <div className="mt-6 flex flex-wrap gap-x-8 gap-y-2 font-mono text-[10px] uppercase tracking-[0.24em] text-white/45">
              <span>{reel.client}</span>
              <span>{reel.role}</span>
              <span>{reel.location}</span>
              <span>{reel.duration}</span>
            </div>
          </motion.div>
        </div>
      </ScrollScale>
    </section>
  );
}
