"use client";

import * as React from "react";
import { motion, useMotionValueEvent, useScroll } from "motion/react";
import { ArrowUpRight } from "lucide-react";

import { useScrollLocked } from "@/hooks/use-scroll-locked";
import { profile } from "@/lib/data";

/**
 * Bar CTA yang menempel di bawah layar mobile.
 * Muncul setelah hero terlewat dan menyingkir saat section kontak terlihat.
 */
export function MobileCta() {
  const { scrollY } = useScroll();
  const [pastHero, setPastHero] = React.useState(false);
  const [atContact, setAtContact] = React.useState(false);

  useMotionValueEvent(scrollY, "change", (value) => {
    setPastHero(value > window.innerHeight * 0.85);
  });

  React.useEffect(() => {
    const target = document.querySelector("#contact");
    if (!target) return;
    const observer = new IntersectionObserver(
      ([entry]) => setAtContact(entry.isIntersecting),
      { rootMargin: "0px 0px -35% 0px" },
    );
    observer.observe(target);
    return () => observer.disconnect();
  }, []);

  // Sembunyikan bar saat dialog / menu terbuka.
  const modalOpen = useScrollLocked();

  const visible = pastHero && !atContact && !modalOpen;

  return (
    <motion.div
      initial={{ y: 140 }}
      animate={{ y: visible ? 0 : 140 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      aria-hidden={!visible}
      className="fixed inset-x-0 bottom-0 z-40 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] md:hidden"
    >
      <div className="flex items-center gap-3 rounded-full border border-white/15 bg-black/80 p-2 pl-4 text-white shadow-[0_8px_30px_rgba(0,0,0,0.5)] backdrop-blur-md">
        <span className="flex min-w-0 flex-1 items-center gap-2 font-mono text-[9px] uppercase tracking-[0.2em] text-white/60">
          <span className="size-1.5 shrink-0 rounded-full bg-emerald-400" />
          <span className="truncate">{profile.statusShort}</span>
        </span>
        <a
          href="#contact"
          tabIndex={visible ? 0 : -1}
          className="inline-flex min-h-11 shrink-0 items-center gap-1.5 rounded-full bg-white px-5 text-sm font-medium text-black"
        >
          Talk to me
          <ArrowUpRight className="size-4" />
        </a>
      </div>
    </motion.div>
  );
}
