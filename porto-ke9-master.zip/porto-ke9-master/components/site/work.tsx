"use client";

import * as React from "react";
import Image from "next/image";
import { AnimatePresence, motion, useMotionValue, useSpring } from "motion/react";
import { ArrowUpRight, X } from "lucide-react";

import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { FadeIn, LineDraw, TextReveal } from "@/components/motion/reveal";
import { SectionMeta } from "@/components/site/section-meta";
import { projects, type Project } from "@/lib/data";

const EASE = [0.16, 1, 0.3, 1] as const;

export function Work() {
  const [hovered, setHovered] = React.useState<Project | null>(null);
  const [selected, setSelected] = React.useState<Project | null>(null);

  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 180, damping: 22, mass: 0.5 });
  const sy = useSpring(y, { stiffness: 180, damping: 22, mass: 0.5 });

  function handleMove(event: React.MouseEvent<HTMLDivElement>) {
    x.set(event.clientX);
    y.set(event.clientY);
  }

  return (
    <section id="work" className="relative bg-black py-20 text-white md:py-32">
      <div className="px-5 md:px-10">
        <SectionMeta
          label="// Selected work"
          detail={`${projects.length} projects — 2023 / 2025`}
          className="text-white/40"
        />
        <LineDraw className="mt-4 bg-white/15 md:mt-5" />

        <h2 className="mt-8 font-heading text-[13vw] uppercase leading-[0.85] md:mt-10 md:text-[7vw]">
          <TextReveal text="Things I have made" />
        </h2>
      </div>

      <div
        className="relative mt-10 px-5 md:mt-20 md:px-10"
        onMouseMove={handleMove}
        onMouseLeave={() => setHovered(null)}
      >
        {projects.map((project, i) => (
          <FadeIn key={project.id} delay={i * 0.04} y={30}>
            <button
              type="button"
              data-cursor="open case"
              onMouseEnter={() => setHovered(project)}
              onClick={() => setSelected(project)}
              className="group grid w-full grid-cols-[64px_minmax(0,1fr)_auto] items-center gap-4 border-t border-white/12 py-5 text-left transition-colors duration-500 hover:border-white/40 active:bg-white/[0.03] md:grid-cols-[70px_1fr_190px_90px_40px] md:gap-x-8 md:py-8"
            >
              {/* Thumbnail hanya di mobile — pengganti preview kursor */}
              <span className="relative block aspect-square w-16 shrink-0 overflow-hidden rounded-sm md:hidden">
                <Image
                  src={project.image}
                  alt=""
                  fill
                  sizes="64px"
                  className="object-cover"
                />
              </span>

              <span className="hidden font-mono text-[10px] text-white/35 md:block">
                {project.index}
              </span>

              <span className="min-w-0">
                <span className="block font-heading text-[7.5vw] uppercase leading-[0.95] transition-all duration-500 group-hover:translate-x-2 group-hover:text-white md:text-[3.4vw]">
                  {project.title}
                </span>
                <span className="mt-1.5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-white/40 md:hidden">
                  <span className="text-white/30">{project.index}</span>
                  <span aria-hidden>·</span>
                  {project.category}
                  <span aria-hidden>·</span>
                  {project.year}
                </span>
              </span>

              <span className="hidden font-mono text-[10px] uppercase tracking-[0.22em] text-white/40 md:block">
                {project.category}
              </span>

              <span className="hidden font-mono text-[10px] text-white/40 md:block">
                {project.year}
              </span>

              <ArrowUpRight className="size-5 shrink-0 text-white/45 transition-all duration-500 md:-translate-x-2 md:text-white md:opacity-0 md:group-hover:translate-x-0 md:group-hover:opacity-100" />
            </button>
          </FadeIn>
        ))}
        <div className="border-t border-white/12" />

        {/* Pratinjau gambar mengikuti kursor (desktop) */}
        <motion.div
          style={{ x: sx, y: sy }}
          className="pointer-events-none fixed left-0 top-0 z-40 hidden md:block"
        >
          <div className="-translate-x-1/2 -translate-y-1/2">
            <AnimatePresence>
              {hovered ? (
                <motion.div
                  key={hovered.id}
                  initial={{ opacity: 0, scale: 0.9, rotate: -4 }}
                  animate={{ opacity: 1, scale: 1, rotate: -2 }}
                  exit={{ opacity: 0, scale: 0.94 }}
                  transition={{ duration: 0.45, ease: EASE }}
                  className="relative h-[22rem] w-[16rem] overflow-hidden rounded-sm shadow-2xl"
                >
                  <Image
                    src={hovered.image}
                    alt=""
                    fill
                    sizes="256px"
                    className="object-cover"
                  />
                </motion.div>
              ) : null}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>

      <ProjectDialog
        project={selected}
        onOpenChange={(open) => !open && setSelected(null)}
      />
    </section>
  );
}

function ProjectDialog({
  project,
  onOpenChange,
}: {
  project: Project | null;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <Dialog open={Boolean(project)} onOpenChange={onOpenChange}>
      <DialogContent
        showCloseButton={false}
        className="max-h-[92dvh] w-[min(1100px,100vw-1.5rem)] max-w-none overflow-y-auto overscroll-contain rounded-2xl border-white/10 bg-neutral-950 p-0 text-white sm:max-w-none"
      >
        {project ? (
          <div>
            <div className="relative h-44 w-full sm:h-56 md:h-80">
              <Image
                src={project.cover}
                alt={project.title}
                fill
                sizes="(max-width: 768px) 100vw, 1100px"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/30 to-transparent" />

              <DialogClose
                aria-label="Tutup"
                className="absolute right-3 top-3 flex size-11 items-center justify-center rounded-full border border-white/20 bg-black/55 backdrop-blur-sm transition-colors hover:bg-black/80"
              >
                <X className="size-5" />
              </DialogClose>
            </div>

            <div className="grid gap-8 p-5 pt-4 md:-mt-14 md:grid-cols-[1.4fr_1fr] md:gap-10 md:p-10">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-white/45">
                  {project.index} — {project.category}
                </p>
                <DialogTitle className="mt-3 font-heading text-3xl uppercase leading-[0.92] sm:text-4xl md:text-6xl">
                  {project.title}
                </DialogTitle>
                <DialogDescription className="mt-4 text-sm leading-relaxed text-white/65 md:mt-5 md:text-base">
                  {project.description}
                </DialogDescription>
                <p className="mt-4 text-sm leading-relaxed text-white/45">
                  {project.about}
                </p>

                <div className="mt-5 flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="outline"
                      className="border-white/20 bg-transparent font-mono text-[10px] uppercase tracking-[0.18em] text-white/70"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>

              <dl className="grid grid-cols-2 gap-x-5 gap-y-5 self-start font-mono text-[10px] uppercase tracking-[0.2em] md:grid-cols-1 md:gap-y-6">
                {[
                  ["Client", project.client],
                  ["Role", project.role],
                  ["Location", project.location],
                  ["Year", project.year],
                  ["Runtime", project.duration],
                ].map(([label, value]) => (
                  <div key={label} className="border-t border-white/12 pt-3">
                    <dt className="text-white/35">{label}</dt>
                    <dd className="mt-1.5 text-white/85">{value}</dd>
                  </div>
                ))}
                {project.awards?.length ? (
                  <div className="col-span-2 border-t border-white/12 pt-3 md:col-span-1">
                    <dt className="text-white/35">Recognition</dt>
                    {project.awards.map((award) => (
                      <dd key={award} className="mt-1.5 text-white/85">
                        {award}
                      </dd>
                    ))}
                  </div>
                ) : null}
              </dl>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
