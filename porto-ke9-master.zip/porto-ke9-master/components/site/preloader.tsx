"use client";

import * as React from "react";
import { AnimatePresence, motion, animate } from "motion/react";

import { useReducedMotion } from "@/hooks/use-media-query";
import { profile } from "@/lib/data";

const EASE = [0.76, 0, 0.24, 1] as const;

export function Preloader() {
  const reduced = useReducedMotion();
  const [done, setDone] = React.useState(false);
  const counterRef = React.useRef<HTMLSpanElement>(null);

  React.useEffect(() => {
    if (reduced) return;

    document.documentElement.classList.add("is-loading");

    const controls = animate(0, 100, {
      duration: 2,
      ease: [0.22, 1, 0.36, 1],
      onUpdate(value) {
        if (counterRef.current) {
          counterRef.current.textContent = Math.round(value)
            .toString()
            .padStart(3, "0");
        }
      },
      onComplete() {
        document.documentElement.classList.remove("is-loading");
        setDone(true);
      },
    });

    return () => {
      controls.stop();
      document.documentElement.classList.remove("is-loading");
    };
  }, [reduced]);

  const visible = !done && !reduced;

  return (
    <AnimatePresence>
      {visible ? (
        <motion.div
          key="preloader"
          className="fixed inset-0 z-[100] flex flex-col justify-between bg-black p-6 text-white md:p-10"
          exit={{ y: "-100%" }}
          transition={{ duration: 1, ease: EASE }}
        >
          <div className="flex items-start justify-between font-mono text-[10px] uppercase tracking-[0.3em] text-white/50">
            <span>{profile.brand}</span>
            <span>{profile.location}</span>
          </div>

          <div className="flex flex-1 items-center justify-center">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, ease: EASE }}
              className="mx-auto max-w-[92vw] text-balance text-center font-heading text-[clamp(2.2rem,10vw,9rem)] uppercase leading-[0.9]"
            >
              {profile.tagline}
            </motion.h2>
          </div>

          <div className="flex items-end justify-between">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-white/50">
              Loading assets
            </span>
            <span
              ref={counterRef}
              className="font-heading text-5xl leading-none tabular-nums md:text-7xl"
            >
              000
            </span>
          </div>

          <motion.div
            className="absolute bottom-0 left-0 h-px w-full origin-left bg-white/40"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 2, ease: [0.22, 1, 0.36, 1] }}
          />
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
