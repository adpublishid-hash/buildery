"use client";

import * as React from "react";
import { motion, useMotionValueEvent, useScroll } from "motion/react";
import { ArrowUpRight } from "lucide-react";

import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Magnetic } from "@/components/motion/magnetic";
import { useScrollLocked } from "@/hooks/use-scroll-locked";
import { navLinks, profile } from "@/lib/data";
import { cn } from "@/lib/utils";

const EASE = [0.16, 1, 0.3, 1] as const;

/** Jam lokal studio — di-update langsung ke DOM agar tidak memicu render ulang. */
function LocalTime({ timeZone }: { timeZone: string }) {
  const ref = React.useRef<HTMLSpanElement>(null);

  React.useEffect(() => {
    const formatter = new Intl.DateTimeFormat("en-GB", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
      timeZone,
    });
    const tick = () => {
      if (ref.current) ref.current.textContent = formatter.format(new Date());
    };
    tick();
    const id = window.setInterval(tick, 15_000);
    return () => window.clearInterval(id);
  }, [timeZone]);

  return <span ref={ref} className="tabular-nums">--:--</span>;
}

export function SiteHeader() {
  const [open, setOpen] = React.useState(false);
  const [hidden, setHidden] = React.useState(false);
  const { scrollY, scrollYProgress } = useScroll();
  const last = React.useRef(0);

  const [scrolled, setScrolled] = React.useState(false);
  const scrollLocked = useScrollLocked();

  useMotionValueEvent(scrollY, "change", (value) => {
    setHidden(value > 240 && value > last.current);
    setScrolled(value > 60);
    last.current = value;
  });

  return (
    <>
      <motion.div
        className="fixed left-0 top-0 z-[70] h-px w-full origin-left bg-foreground/70 mix-blend-difference"
        style={{ scaleX: scrollYProgress }}
      />

      <motion.header
        initial={{ y: -100 }}
        animate={{ y: !open && (hidden || scrollLocked) ? -120 : 0 }}
        transition={{ duration: 0.6, ease: EASE }}
        className="fixed inset-x-0 top-0 z-[80] md:mix-blend-difference"
      >
        {/* Scrim tipis di puncak halaman; berubah jadi bar solid setelah scroll.
            Mix-blend hanya dipakai di layar besar agar tetap terbaca di mobile. */}
        <div
          className={cn(
            "pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-black/85 via-black/40 to-transparent transition-opacity duration-300 md:hidden",
            scrolled && "opacity-0",
          )}
          aria-hidden
        />
        <div
          className={cn(
            "relative flex items-center justify-between px-5 py-5 text-white transition-colors duration-300 md:bg-transparent md:px-10 md:py-7 md:backdrop-blur-none",
            scrolled && "bg-black/75 backdrop-blur-md",
          )}
        >
          <a
            href="#top"
            data-cursor="hover"
            className="-my-2 inline-flex min-h-11 items-center font-heading text-lg uppercase leading-none tracking-[0.14em] md:text-xl"
          >
            {profile.brand}
          </a>

          <div className="hidden items-center gap-10 font-mono text-[10px] uppercase tracking-[0.28em] text-white/70 lg:flex">
            <span className="flex items-center gap-1">
              <LocalTime timeZone={profile.timezone} /> WIB
            </span>
            <span className="whitespace-nowrap text-white/50">
              {profile.addressShort}
            </span>
          </div>

          <div className="flex items-center gap-3 md:gap-5">
            <Magnetic className="hidden sm:inline-flex">
              <a
                href="#contact"
                data-cursor="hover"
                className="group inline-flex items-center gap-2 rounded-full border border-white/40 px-5 py-2 font-mono text-[10px] uppercase tracking-[0.24em] transition-colors hover:bg-white hover:text-black"
              >
                Talk to me
                <ArrowUpRight className="size-3 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </Magnetic>

            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <button
                  type="button"
                  aria-label="Buka menu"
                  data-cursor="menu"
                  className="-mr-2 flex size-11 flex-col items-center justify-center gap-[5px]"
                >
                  <span
                    className={cn(
                      "block h-px w-6 bg-white transition-transform duration-300",
                      open && "translate-y-[3px] rotate-45",
                    )}
                  />
                  <span
                    className={cn(
                      "block h-px w-6 bg-white transition-transform duration-300",
                      open && "-translate-y-[3px] -rotate-45",
                    )}
                  />
                </button>
              </SheetTrigger>

              <SheetContent
                side="top"
                showCloseButton={false}
                className="data-[side=top]:h-dvh gap-0 border-0 bg-black text-white sm:max-w-none"
              >
                <SheetTitle className="sr-only">Menu navigasi</SheetTitle>
                <SheetDescription className="sr-only">
                  Pilih bagian halaman yang ingin dituju.
                </SheetDescription>
                <MenuBody onNavigate={() => setOpen(false)} />
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </motion.header>

    </>
  );
}

function MenuBody({ onNavigate }: { onNavigate: () => void }) {
  return (
    <div className="flex h-full flex-col justify-between overflow-y-auto px-5 pb-[max(2rem,env(safe-area-inset-bottom))] pt-20 md:px-10 md:pb-12 md:pt-32">
      <nav className="flex flex-1 flex-col justify-center md:flex-none md:justify-start">
        {navLinks.map((link, i) => (
          <SheetClose asChild key={link.href}>
            <motion.a
              href={link.href}
              onClick={onNavigate}
              data-cursor="hover"
              initial={{ y: 60, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.08 * i + 0.1, ease: EASE }}
              className="group flex items-center gap-4 border-b border-white/10 py-3 md:items-baseline md:gap-8 md:py-5"
            >
              <span className="font-mono text-[10px] text-white/40">{link.index}</span>
              <span className="font-heading text-[12vw] uppercase leading-[1] transition-transform duration-500 group-hover:translate-x-3 md:text-[7vw] md:leading-[0.9]">
                {link.label}
              </span>
              <ArrowUpRight className="ml-auto size-5 text-white/40 transition-all duration-500 md:-translate-x-2 md:size-8 md:text-white md:opacity-0 md:group-hover:translate-x-0 md:group-hover:opacity-100" />
            </motion.a>
          </SheetClose>
        ))}
      </nav>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.45 }}
        className="mt-8 md:hidden"
      >
        <a
          href="#contact"
          onClick={onNavigate}
          className="flex min-h-12 items-center justify-center gap-2 rounded-full bg-white px-6 text-sm font-medium text-black"
        >
          Talk to me
          <ArrowUpRight className="size-4" />
        </a>
        <p className="mt-3 text-center font-mono text-[9px] uppercase tracking-[0.24em] text-white/40">
          {profile.status}
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="mt-8 grid gap-5 border-t border-white/10 pt-6 font-mono text-[10px] uppercase tracking-[0.24em] text-white/50 md:mt-10 md:grid-cols-3 md:gap-6"
      >
        <div className="space-y-1">
          <p className="text-white/30">Email</p>
          <a href={`mailto:${profile.email}`} className="text-white hover:underline">
            {profile.email}
          </a>
        </div>
        <div className="space-y-1">
          <p className="text-white/30">Studio</p>
          <p className="text-white/70">{profile.location}</p>
        </div>
        <div className="flex flex-wrap gap-4">
          {profile.socials.map((s) => (
            <a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noreferrer"
              className="text-white/70 transition-colors hover:text-white"
            >
              {s.label}
            </a>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
