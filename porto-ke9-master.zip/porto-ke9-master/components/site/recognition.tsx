"use client";

import * as React from "react";

import { Marquee } from "@/components/motion/marquee";
import { FadeIn, LineDraw, TextReveal } from "@/components/motion/reveal";
import { SectionMeta } from "@/components/site/section-meta";
import { awards, clients, experiences } from "@/lib/data";

export function Recognition() {
  return (
    <section id="recognition" className="relative bg-black py-20 text-white md:py-32">
      <div className="px-5 md:px-10">
        <SectionMeta
          label="// Recognition & track record"
          detail={`${awards.length} entries`}
          className="text-white/40"
        />
        <LineDraw className="mt-4 bg-white/15 md:mt-5" />

        <h2 className="mt-8 font-heading text-[12vw] uppercase leading-[0.86] md:mt-10 md:text-[6.5vw]">
          <TextReveal text="Awards & experience" />
        </h2>

        <div className="mt-10 grid gap-12 md:mt-16 md:grid-cols-2 md:gap-20">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-white/40">
              Selected awards
            </p>
            <ul className="mt-6">
              {awards.map((award, i) => (
                <FadeIn as="li" key={`${award.title}-${i}`} delay={i * 0.05} y={20}>
                  <div className="group grid grid-cols-[52px_1fr] items-start gap-4 border-t border-white/12 py-5 transition-colors hover:border-white/40">
                    <span className="font-mono text-[11px] text-white/40">
                      {award.year}
                    </span>
                    <div>
                      <p className="font-heading text-xl uppercase leading-tight transition-transform duration-500 group-hover:translate-x-1.5 md:text-2xl">
                        {award.title}
                      </p>
                      <p className="mt-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-white/40">
                        {award.organization} — {award.category}
                      </p>
                    </div>
                  </div>
                </FadeIn>
              ))}
            </ul>
          </div>

          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-white/40">
              Career timeline
            </p>
            <ol className="mt-6 border-l border-white/12 pl-6">
              {experiences.map((item, i) => (
                <FadeIn as="li" key={item.company} delay={i * 0.06} y={20}>
                  <div className="relative pb-8 md:pb-10">
                    <span className="absolute -left-[27px] top-1.5 size-2 rounded-full bg-white/70" />
                    <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-white/40">
                      {item.period} — {item.location}
                    </p>
                    <p className="mt-2 font-heading text-2xl uppercase leading-tight">
                      {item.role}
                    </p>
                    <p className="mt-1 text-sm text-white/70">{item.company}</p>
                    <p className="mt-3 max-w-md text-sm leading-relaxed text-white/45">
                      {item.description}
                    </p>
                  </div>
                </FadeIn>
              ))}
            </ol>
          </div>
        </div>
      </div>

      <div className="mt-14 border-y border-white/10 py-6 md:mt-20 md:py-8">
        <p className="mb-6 px-5 font-mono text-[10px] uppercase tracking-[0.28em] text-white/35 md:px-10">
          Trusted by
        </p>
        <Marquee baseVelocity={18} reverse repeat={4} itemClassName="gap-12 pr-12 md:gap-20 md:pr-20">
          {clients.map((client) => (
            <span
              key={client}
              className="flex items-center gap-12 font-heading text-xl uppercase text-white/45 md:gap-20 md:text-3xl"
            >
              {client}
            </span>
          ))}
        </Marquee>
      </div>
    </section>
  );
}
