"use client";

import * as React from "react";
import { ChevronDown } from "lucide-react";

import { FadeIn, LineDraw, TextReveal } from "@/components/motion/reveal";
import { Parallax, ParallaxImage } from "@/components/motion/parallax";
import { Counter } from "@/components/motion/counter";
import { profile, stats, process } from "@/lib/data";
import { cn } from "@/lib/utils";

export function About() {
  return (
    <section
      id="about"
      className="section-light relative bg-background text-foreground"
    >
      <div className="px-5 pt-20 md:px-10 md:pt-32">
        <div className="flex flex-col gap-1 font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground sm:flex-row sm:items-baseline sm:justify-between">
          <span>{"// About me"}</span>
          <span className="hidden lg:inline">{profile.address}</span>
          <span className="opacity-60">Est. {profile.since}</span>
        </div>
        <LineDraw className="mt-4 md:mt-5" />
      </div>

      <div className="grid gap-8 px-5 py-10 md:grid-cols-[1.6fr_1fr] md:gap-16 md:px-10 md:py-20">
        <h2 className="font-heading text-[13vw] uppercase leading-[0.85] md:text-[7.5vw]">
          <TextReveal text="Directing moments" />
          <br />
          <TextReveal text="that matter" delay={0.15} />
        </h2>
        <FadeIn delay={0.2} className="self-end">
          <p className="max-w-sm text-sm leading-relaxed text-muted-foreground md:text-base">
            {profile.shortBio}
          </p>
          <p className="mt-6 font-mono text-[10px] uppercase tracking-[0.24em] text-foreground/70">
            {profile.role}
          </p>
        </FadeIn>
      </div>

      {/* Foto lebar dengan parallax internal */}
      <ParallaxImage
        src={profile.portrait}
        alt={`Dokumentasi ${profile.name} di lokasi syuting`}
        className="h-[52vh] w-full md:h-[78vh]"
        sizes="100vw"
        amount={12}
        overlay={false}
      />

      {/* Bio panjang + statistik */}
      <div className="grid gap-10 px-5 py-14 md:grid-cols-[0.9fr_1.1fr] md:gap-20 md:px-10 md:py-28">
        <div>
          <FadeIn>
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              {"// Biography"}
            </p>
            <p className="mt-5 font-heading text-[7.5vw] uppercase leading-[1.05] sm:text-3xl md:mt-8 md:text-5xl">
              {profile.manifesto}
            </p>
          </FadeIn>

          <div className="mt-10 grid grid-cols-2 gap-x-6 gap-y-8 md:mt-12 md:gap-y-10">
            {stats.map((stat, i) => (
              <FadeIn key={stat.label} delay={i * 0.08}>
                <div className="border-t border-border pt-4">
                  <p className="font-heading text-4xl leading-none tabular-nums md:text-6xl">
                    <Counter to={stat.value} suffix={stat.suffix} />
                  </p>
                  <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    {stat.label}
                  </p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <Biography paragraphs={profile.bio} />

          <Parallax speed={0.06} className="pt-4 md:pt-6">
            <div className="grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2">
              {process.map((item) => (
                <div key={item.step} className="bg-background p-5 md:p-6">
                  <p className="font-mono text-[10px] tracking-[0.24em] text-muted-foreground">
                    {item.step}
                  </p>
                  <p className="mt-3 font-heading text-xl uppercase">{item.title}</p>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {item.text}
                  </p>
                </div>
              ))}
            </div>
          </Parallax>
        </div>
      </div>
    </section>
  );
}

/**
 * Bio panjang. Di mobile hanya dua paragraf pertama yang tampil sampai
 * pembaca menekan "Baca selengkapnya"; di layar besar tampil penuh.
 */
function Biography({ paragraphs }: { paragraphs: string[] }) {
  const [expanded, setExpanded] = React.useState(false);
  const preview = 2;

  return (
    <div className="space-y-5 md:space-y-6">
      {paragraphs.map((paragraph, i) => (
        <FadeIn
          key={i}
          delay={i * 0.06}
          className={cn(
            i >= preview && !expanded && "hidden md:block",
          )}
        >
          <p className="text-sm leading-relaxed text-muted-foreground md:text-base">
            {paragraph}
          </p>
        </FadeIn>
      ))}

      {paragraphs.length > preview ? (
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          aria-expanded={expanded}
          className="inline-flex min-h-11 items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-foreground underline underline-offset-4 md:hidden"
        >
          {expanded ? "Tutup bio" : "Baca selengkapnya"}
          <ChevronDown
            className={cn("size-4 transition-transform", expanded && "rotate-180")}
          />
        </button>
      ) : null}
    </div>
  );
}
