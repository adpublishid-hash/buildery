"use client";

import * as React from "react";
import { AnimatePresence, motion } from "motion/react";

import { LineDraw } from "@/components/motion/reveal";
import { testimonials } from "@/lib/data";
import { cn } from "@/lib/utils";

const EASE = [0.16, 1, 0.3, 1] as const;

export function Testimonials() {
  const [index, setIndex] = React.useState(0);
  const active = testimonials[index];

  React.useEffect(() => {
    const id = window.setInterval(
      () => setIndex((i) => (i + 1) % testimonials.length),
      6500,
    );
    return () => window.clearInterval(id);
  }, []);

  return (
    <section className="section-light bg-background py-20 text-foreground md:py-32">
      <div className="px-5 md:px-10">
        <div className="flex items-baseline justify-between font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
          <span>{"// Kind words"}</span>
          <span className="tabular-nums">
            0{index + 1} / 0{testimonials.length}
          </span>
        </div>
        <LineDraw className="mt-4 md:mt-5" />

        <div className="relative mt-8 min-h-[19rem] sm:min-h-[16rem] md:mt-14 md:min-h-[20rem]">
          <AnimatePresence mode="wait">
            <motion.blockquote
              key={active.name}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.7, ease: EASE }}
              className="max-w-5xl"
            >
              <p className="font-heading text-[6.4vw] uppercase leading-[1.05] sm:text-[5vw] md:text-[3.4vw] md:leading-[1]">
                “{active.quote}”
              </p>
              <footer className="mt-6 font-mono text-[10px] uppercase leading-relaxed tracking-[0.24em] text-muted-foreground md:mt-8">
                {active.name} — {active.title}, {active.company}
              </footer>
            </motion.blockquote>
          </AnimatePresence>
        </div>

        <div className="mt-4 flex md:mt-6">
          {testimonials.map((t, i) => (
            <button
              key={t.name}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Testimoni dari ${t.name}`}
              aria-current={i === index}
              className="flex h-11 items-center pr-2"
            >
              <span
                className={cn(
                  "block h-1 rounded-full transition-all duration-500",
                  i === index ? "w-10 bg-foreground" : "w-4 bg-foreground/25",
                )}
              />
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
