"use client";

import * as React from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { ArrowRight } from "lucide-react";

import { ParallaxImage } from "@/components/motion/parallax";
import { TextReveal } from "@/components/motion/reveal";
import { Magnetic } from "@/components/motion/magnetic";
import { projects } from "@/lib/data";

export function Cta() {
  const ref = React.useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const lift = useTransform(scrollYProgress, [0, 1], ["18%", "-18%"]);

  return (
    <section ref={ref} className="relative bg-black">
      <ParallaxImage
        src={projects[4].cover}
        alt="Cahaya menembus jendela gudang saat syuting"
        className="h-[78vh] min-h-[560px] w-full md:h-[95vh]"
        sizes="100vw"
        amount={16}
        scale={1.3}
      >
        <div className="grain absolute inset-0 overflow-hidden" aria-hidden />

        {/* Lapisan gelap ekstra di mobile supaya teks tetap kontras */}
        <div className="absolute inset-0 bg-black/45 md:hidden" aria-hidden />

        <div className="pointer-events-none absolute inset-0 grid grid-cols-3 md:grid-cols-5">
          {Array.from({ length: 5 }).map((_, i) => (
            <div
              key={i}
              className={i > 2 ? "hidden border-l border-white/10 md:block" : "border-l border-white/10"}
            />
          ))}
        </div>

        <motion.div
          style={{ y: lift }}
          className="absolute inset-0 flex flex-col justify-center px-5 text-white md:px-10"
        >
          <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-white/45">
            {"// Let us build something"}
          </p>
          <h2 className="mt-6 max-w-4xl font-heading text-[12vw] uppercase leading-[0.86] md:text-[5.8vw]">
            <TextReveal text="Ready to bring your" />
            <br />
            <TextReveal text="next big vision to life?" delay={0.12} />
          </h2>

          <Magnetic className="mt-8 self-start md:mt-10">
            <a
              href="#contact"
              data-cursor="say hello"
              className="group inline-flex min-h-12 items-center gap-3 rounded-full bg-white px-7 py-4 text-sm font-medium text-black transition-colors hover:bg-white/85 md:px-8"
            >
              Start a project
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
            </a>
          </Magnetic>

          <p className="mt-6 max-w-md text-sm leading-relaxed text-white/70 md:mt-8 md:text-white/55">
            Entah kamu sedang menyiapkan kampanye brand global atau video musik
            sinematik, mari bicara sebelum kamera dinyalakan.
          </p>
        </motion.div>
      </ParallaxImage>
    </section>
  );
}
