"use client";

import * as React from "react";
import { ReactLenis } from "lenis/react";

import { useReducedMotion } from "@/hooks/use-media-query";

/** Smooth scrolling global (Lenis) + dukungan prefers-reduced-motion. */
export function SmoothScroll({ children }: { children: React.ReactNode }) {
  const reduced = useReducedMotion();

  if (reduced) return <>{children}</>;

  return (
    <ReactLenis
      root
      options={{
        lerp: 0.09,
        duration: 1.2,
        smoothWheel: true,
        wheelMultiplier: 1,
        touchMultiplier: 1.6,
      }}
    >
      {children}
    </ReactLenis>
  );
}
