import { Preloader } from "@/components/site/preloader";
import { Cursor } from "@/components/site/cursor";
import { SiteHeader } from "@/components/site/site-header";
import { Hero } from "@/components/site/hero";
import { Ticker } from "@/components/site/ticker";
import { About } from "@/components/site/about";
import { Showreel } from "@/components/site/showreel";
import { Work } from "@/components/site/work";
import { Services } from "@/components/site/services";
import { Recognition } from "@/components/site/recognition";
import { Testimonials } from "@/components/site/testimonials";
import { Cta } from "@/components/site/cta";
import { Contact } from "@/components/site/contact";
import { MobileCta } from "@/components/site/mobile-cta";

export default function Home() {
  return (
    <>
      <Preloader />
      <Cursor />
      <SiteHeader />

      <main className="relative w-full bg-black">
        <Hero />
        <Ticker />
        <About />
        <Showreel />
        <Work />
        <Services />
        <Recognition />
        <Testimonials />
        <Cta />
      </main>

      <Contact />
      <MobileCta />
    </>
  );
}
